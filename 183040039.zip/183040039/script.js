let mahasiswa = {

	nama : "Sandhika Galih",
	nrp : "03040323",
	email : "sandhikagalih@unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));